/*    ---NOTES---
on can be added to listeners that are
available at start, since no li will be
at start on will be added to ul

for if statements make sure to use rgb instead  
of named colors*/


//check off specific todos by clicking
$("ul").on("click", "li", function(){
	$(this).toggleClass("completed");
});

//click on X to delete todo
$("ul").on("click", "span", function(event){
	$(this).parent().fadeOut(500, function(){
		$(this).remove() //$(this) is for parent
	}); //fades li out
	event.stopPropagation();
	//stopPropagation() stops event bubbling
});

$("input[type='text']").keypress(function(event){
	//ASCII code for enter is 13
	if(event.which === 13){			
		//grabbing new text from input
		var todoText = $(this).val();
		$(this).val("");
		//create a new li and add to ul
		$("ul").append("<li><span><i class='fas fa-trash'></i></span> " + todoText + "</li>");
	}
});

$(".fa-plus").click(function(){
	$("input[type='text']").fadeToggle();
});